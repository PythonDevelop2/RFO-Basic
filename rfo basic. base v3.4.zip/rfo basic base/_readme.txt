﻿RFO BASIC!. base v3.4
Examples. Примеры
by Python_develop

Contacts. Контакты:
n72645937@gmail.com
jimm9867@yandex.ru

📂 Work folder. Рабочая папка:
rfo-basic/
Resources folder. Папка ресурсов:
../data
Scripts folder. Папка скриптов:
../source

